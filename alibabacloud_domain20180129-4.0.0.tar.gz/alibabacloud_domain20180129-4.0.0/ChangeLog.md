2024-08-26 Version: 3.15.0
- Support API SaveSingleTaskForReserveDropListDomain.
- Update API CheckDomain: update response param.
- Update API GetOperationOssUploadPolicy: update param AuditType.
- Update API QueryAdvancedDomainList: add param IsPremiumDomain.
- Update API QueryDomainList: update response param.
- Update API QueryEmailVerification: update param Email.
- Update API QueryRegistrantProfiles: add param Remark.
- Update API QueryRegistrantProfiles: update response param.
- Update API QueryTaskDetailList: update response param.
- Update API SaveBatchDomainRemark: update param InstanceIds.
- Update API SaveBatchTaskForCreatingOrderActivate: update param OrderActivateParam.
- Update API SaveDomainGroup: update param DomainGroupName.


2024-04-12 Version: 3.14.13
- Update API SaveBatchTaskForReserveDropListDomain: update param Domains.


2024-03-20 Version: 3.14.11
- Update API DeleteDomainGroup: update param DomainGroupId.
- Update API QueryDomainList: add param Ccompany.
- Update API QueryDomainList: update response param.


2024-01-25 Version: 3.14.10
- Update API SaveBatchTaskForReserveDropListDomainupdate Domains param.


2023-11-07 Version: 3.14.9
- Generated python 2018-01-29 for Domain.

2022-07-21 Version: 3.14.8
- Ram action config.

2021-03-24 Version: 1.0.1
- Generated python 2018-01-29 for Domain.

2020-12-30 Version: 1.0.0
- AMP Version Change.

2020-12-30 Version: 1.0.0
- AMP Version Change.

